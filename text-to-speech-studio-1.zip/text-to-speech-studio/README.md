# Text-to-Speech Studio

A responsive browser-based text-to-speech app built with HTML, CSS, and vanilla JavaScript.

## Project structure

```text
text-to-speech-studio/
├── index.html
├── styles.css
├── script.js
└── README.md
```

## Run it

1. Extract the project folder.
2. Open `index.html` in a recent browser.
3. For the most reliable clipboard permissions and voice loading, serve the folder from localhost:
   - If Python is installed, open a terminal in the folder and run `python -m http.server 8000`.
   - Visit `http://localhost:8000`.
4. Choose a language and an available voice, type text, and select **Play speech**.

No package installation or API key is required for browser playback.

## Features

- Browser-native speech with voice, language, speed, pitch, and volume controls.
- Pause, resume, stop, and voice preview.
- Long text split into chunks at paragraph/sentence/word boundaries.
- Character and word counters, sample text, clear, paste, copy.
- Recent text history saved locally in the browser, with a clear-history control.
- Light/dark theme, keyboard shortcuts, responsive layout, and live status messages.
- Audio download is deliberately disabled in browser-only mode.

## Keyboard shortcuts

- `Ctrl + Enter` (Windows/Linux) or `Cmd + Enter` (Mac): Play speech.
- `Escape`: Stop speech.

## Audio export limitation and provider integration

The standard Web Speech API does not expose the generated audio bytes as a `Blob`. Therefore this project **does not create a fake MP3/WAV file**. To enable genuine audio downloads, add a server endpoint that accepts text and voice settings, calls a real TTS provider, and returns actual audio bytes with an appropriate `Content-Type` such as `audio/mpeg` or `audio/wav`.

Suggested frontend provider contract:

```js
// Example shape for a future provider adapter; not active in browser-only mode.
const ttsProvider = {
  async generateAudio({ text, voice, language, rate, pitch, volume }) {
    const response = await fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, voice, language, rate, pitch, volume })
    });
    if (!response.ok) throw new Error("Audio generation failed");
    return {
      blob: await response.blob(),
      mimeType: response.headers.get("Content-Type") || "audio/mpeg"
    };
  }
};
```

The backend must authenticate requests, validate input and provider limits, rate-limit usage, and keep secret API keys in server environment variables. Do not put secret keys in `script.js`. After receiving a real `Blob`, create a temporary object URL with `URL.createObjectURL(blob)`, provide a download link using a matching extension, then call `URL.revokeObjectURL(url)` when it is no longer needed. The exact backend depends on the selected provider and is intentionally not fabricated here.

## Browser limitations

- Voices differ across operating systems and browsers; some voices download lazily or appear after a delay.
- A language in the menu does not mean a matching installed voice exists. The app reports when no matching voice is available.
- Browser speech synthesis does not provide standard audio export, so the Download Audio button remains disabled.
- Pause/resume reliability and chunk transitions can vary by browser/OS speech engine.
- Clipboard read access commonly requires HTTPS or localhost and user permission.
- Local history and theme preferences remain on this browser/device until cleared. Avoid storing sensitive text.

## Test checklist

- [ ] Play a short sentence and several paragraphs.
- [ ] Try Play with an empty editor.
- [ ] Pause, resume, then stop a speech session.
- [ ] Switch voices and languages; try a language without an installed voice.
- [ ] Change rate, pitch, and volume and replay.
- [ ] Paste with permission granted and denied; test copy.
- [ ] Test a long script and verify chunks remain in order.
- [ ] Reload and confirm recent text/theme restoration.
- [ ] Test at mobile width and keyboard navigation.
- [ ] Confirm Download Audio stays disabled until a real provider/backend is configured.
- [ ] If adding a provider, test actual MP3/WAV bytes, network failure, invalid responses, provider limits, and cleanup of object URLs.
