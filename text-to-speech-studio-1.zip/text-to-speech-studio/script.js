(() => {
  "use strict";

  const MAX_CHARS = 50000;
  const HISTORY_KEY = "tts-studio-history-v1";
  const THEME_KEY = "tts-studio-theme-v1";
  const SAMPLE_TEXT = "Welcome to Text-to-Speech Studio. This is a simple example of how written words can become spoken audio. Try changing the voice, speed, pitch, and volume to explore what works best for you.";

  const $ = (id) => document.getElementById(id);
  const els = {};
  [
    "textInput","wordCount","charCount","validationMessage","clearBtn","pasteBtn","sampleBtn","copyBtn",
    "recentSelect","deleteHistoryBtn","themeToggle","languageSelect","voiceSelect","voiceCount","voiceMessage",
    "previewVoiceBtn","rateSlider","rateValue","pitchSlider","pitchValue","volumeSlider","volumeValue",
    "resetBtn","playBtn","pauseBtn","resumeBtn","stopBtn","playbackStatus","activeVoiceName","activeLanguage",
    "progressLabel","progressBar","progressFill","downloadBtn","downloadInfo","toast","confirmDialog",
    "dialogTitle","dialogMessage","confirmActionBtn"
  ].forEach((id) => { els[id] = $(id); });

  const state = {
    voices: [],
    chunks: [],
    chunkIndex: 0,
    utterance: null,
    session: 0,
    status: "ready",
    toastTimer: null,
    history: [],
    dialogAction: null,
    lastSpokenText: ""
  };

  const languageNames = new Map([
    ["en-US","English (US)"],["en-GB","English (UK)"],["hi-IN","Hindi"],["mr-IN","Marathi"],
    ["es-ES","Spanish"],["fr-FR","French"],["de-DE","German"],["ja-JP","Japanese"],["ar-SA","Arabic"]
  ]);

  function initializeApp() {
    els.textInput.maxLength = MAX_CHARS;
    loadTheme();
    loadHistory();
    updateTextCounters();
    updateSliderLabels();
    bindEvents();
    updatePlaybackStatus("ready", "Ready to play");
    updatePlayerButtons();
    loadVoices();
    if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
      showNotification("Speech synthesis is not supported in this browser.");
      updatePlaybackStatus("error", "Speech not supported");
      els.playBtn.disabled = true;
      els.previewVoiceBtn.disabled = true;
      els.voiceMessage.textContent = "Your browser does not support speech synthesis. Try a recent version of Chrome, Edge, Safari, or Firefox.";
    }
  }

  function bindEvents() {
    els.textInput.addEventListener("input", () => {
      updateTextCounters();
      els.validationMessage.textContent = "";
      if (state.status === "playing" || state.status === "paused" || state.status === "starting") stopSpeech(false);
      updatePlaybackStatus("ready", "Text updated — ready to play");
      saveCurrentTextToHistory(false);
    });
    els.clearBtn.addEventListener("click", () => {
      if (!els.textInput.value) { showNotification("The editor is already empty."); return; }
      openConfirm("Clear text?", "Remove all text from the editor?", "Clear text", () => {
        els.textInput.value = "";
        updateTextCounters();
        els.validationMessage.textContent = "";
        stopSpeech(false);
        updatePlaybackStatus("ready", "Ready to play");
        saveCurrentTextToHistory(true);
      });
    });
    els.pasteBtn.addEventListener("click", pasteText);
    els.sampleBtn.addEventListener("click", () => {
      els.textInput.value = SAMPLE_TEXT;
      updateTextCounters();
      els.validationMessage.textContent = "";
      saveCurrentTextToHistory(true);
      showNotification("Sample text added.");
    });
    els.copyBtn.addEventListener("click", copyText);
    els.deleteHistoryBtn.addEventListener("click", () => {
      openConfirm("Clear recent history?", "This permanently removes saved scripts from this browser.", "Clear history", clearHistory);
    });
    els.recentSelect.addEventListener("change", () => {
      const item = state.history.find((entry) => entry.id === els.recentSelect.value);
      if (!item) return;
      els.textInput.value = item.text;
      updateTextCounters();
      els.validationMessage.textContent = "";
      showNotification("Recent text restored.");
    });
    els.themeToggle.addEventListener("click", toggleTheme);
    els.languageSelect.addEventListener("change", () => {
      populateVoiceOptions();
      updateActiveVoiceInfo();
    });
    els.voiceSelect.addEventListener("change", updateActiveVoiceInfo);
    ["rateSlider","pitchSlider","volumeSlider"].forEach((id) => els[id].addEventListener("input", updateSliderLabels));
    els.previewVoiceBtn.addEventListener("click", previewVoice);
    els.resetBtn.addEventListener("click", resetSettings);
    els.playBtn.addEventListener("click", speakText);
    els.pauseBtn.addEventListener("click", pauseSpeech);
    els.resumeBtn.addEventListener("click", resumeSpeech);
    els.stopBtn.addEventListener("click", () => stopSpeech(true));
    els.downloadBtn.addEventListener("click", downloadAudio);
    els.confirmActionBtn.addEventListener("click", (event) => {
      event.preventDefault();
      const action = state.dialogAction;
      state.dialogAction = null;
      els.confirmDialog.close();
      if (action) action();
    });
    document.addEventListener("keydown", (event) => {
      const isMac = navigator.platform.toUpperCase().includes("MAC");
      if ((isMac ? event.metaKey : event.ctrlKey) && event.key === "Enter") {
        event.preventDefault();
        speakText();
      } else if (event.key === "Escape" && !els.confirmDialog.open) {
        stopSpeech(true);
      }
    });
    window.addEventListener("beforeunload", () => {
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    });
    if ("speechSynthesis" in window) {
      window.speechSynthesis.addEventListener("voiceschanged", loadVoices);
    }
  }

  function loadVoices() {
    if (!("speechSynthesis" in window)) return;
    const voices = window.speechSynthesis.getVoices();
    state.voices = Array.isArray(voices) ? voices : [];
    populateVoiceOptions();
    if (!state.voices.length) {
      els.voiceCount.textContent = "0 available";
      els.voiceMessage.textContent = "No voices are available yet. Your browser may still be loading voices, or your device may not have speech voices installed.";
    }
  }

  function populateVoiceOptions() {
    const lang = els.languageSelect.value;
    const matches = state.voices.filter((voice) => voice.lang.toLowerCase() === lang.toLowerCase()
      || voice.lang.toLowerCase().startsWith(lang.split("-")[0].toLowerCase() + "-"));
    const previous = els.voiceSelect.value;
    els.voiceSelect.replaceChildren();
    if (!matches.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No matching voices available";
      els.voiceSelect.append(option);
      els.voiceSelect.disabled = true;
      els.voiceCount.textContent = `${state.voices.length} total`;
      els.voiceMessage.textContent = state.voices.length
        ? `No installed voice matches ${languageNames.get(lang) || lang}. Try another language or install a speech pack on your device.`
        : "No browser voices found. Try reloading or checking your device's speech settings.";
      return;
    }
    matches.sort((a,b) => Number(b.default) - Number(a.default) || a.name.localeCompare(b.name));
    matches.forEach((voice) => {
      const option = document.createElement("option");
      option.value = voice.voiceURI;
      option.textContent = `${voice.name}${voice.default ? " (default)" : ""}`;
      els.voiceSelect.append(option);
    });
    const preferred = matches.find((v) => v.voiceURI === previous) || matches.find((v) => v.default) || matches[0];
    els.voiceSelect.value = preferred.voiceURI;
    els.voiceSelect.disabled = false;
    els.voiceCount.textContent = `${matches.length} available`;
    els.voiceMessage.textContent = "Choose a voice and preview it before reading your script.";
  }

  function updateTextCounters() {
    const text = els.textInput.value;
    const words = text.trim() ? text.trim().split(/\s+/u).length : 0;
    els.wordCount.textContent = words.toLocaleString();
    els.charCount.textContent = text.length.toLocaleString();
    els.charCount.parentElement.classList.toggle("over-limit", text.length >= MAX_CHARS);
    els.playBtn.disabled = !("speechSynthesis" in window) || !text.trim();
    els.copyBtn.disabled = !text.length;
    els.clearBtn.disabled = !text.length;
  }

  function validateText() {
    if (!els.textInput.value.trim()) {
      els.validationMessage.textContent = "Add some text first, then press Play speech.";
      els.textInput.focus();
      return false;
    }
    if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
      els.validationMessage.textContent = "Speech synthesis is not supported in this browser.";
      return false;
    }
    if (els.textInput.value.length > MAX_CHARS) {
      els.validationMessage.textContent = `Please keep the text under ${MAX_CHARS.toLocaleString()} characters.`;
      return false;
    }
    els.validationMessage.textContent = "";
    return true;
  }

  function splitTextIntoChunks(text, maxLength = 180) {
    // Split on sentence/paragraph boundaries first; split oversized sentences at word boundaries.
    const paragraphs = text.match(/[^\n]+(?:\n+|$)|\n+/g) || [text];
    const chunks = [];
    let current = "";
    const pushCurrent = () => { if (current.trim()) chunks.push(current.trim()); current = ""; };
    for (const paragraph of paragraphs) {
      const p = paragraph.trim();
      if (!p) continue;
      if ((current + (current ? "\n" : "") + p).length <= maxLength) {
        current += (current ? "\n" : "") + p;
        continue;
      }
      pushCurrent();
      const sentences = p.match(/[^.!?。！？]+[.!?。！？]+["'”’)]*|[^.!?。！？]+$/gu) || [p];
      for (const sentenceRaw of sentences) {
        const sentence = sentenceRaw.trim();
        if (!sentence) continue;
        if (sentence.length > maxLength) {
          pushCurrent();
          const words = sentence.split(/\s+/u);
          let part = "";
          for (const word of words) {
            if (part && (part + " " + word).length > maxLength) {
              chunks.push(part);
              part = word;
            } else {
              part += (part ? " " : "") + word;
            }
          }
          if (part) current = part;
        } else if ((current + (current ? " " : "") + sentence).length <= maxLength) {
          current += (current ? " " : "") + sentence;
        } else {
          pushCurrent();
          current = sentence;
        }
      }
      if (current.length >= maxLength) pushCurrent();
    }
    pushCurrent();
    return chunks.length ? chunks : [text.trim()];
  }

  function createUtterance(text, sessionId) {
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = state.voices.find((v) => v.voiceURI === els.voiceSelect.value);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang || els.languageSelect.value;
    } else {
      utterance.lang = els.languageSelect.value;
    }
    utterance.rate = Number(els.rateSlider.value);
    utterance.pitch = Number(els.pitchSlider.value);
    utterance.volume = Number(els.volumeSlider.value);
    utterance.onstart = () => {
      if (sessionId !== state.session) return;
      state.status = "playing";
      updatePlaybackStatus("playing", "Speaking");
      updatePlayerButtons();
    };
    utterance.onend = () => {
      if (sessionId !== state.session) return;
      state.chunkIndex += 1;
      if (state.chunkIndex < state.chunks.length) {
        speakNextChunk(sessionId);
      } else {
        state.utterance = null;
        state.status = "ready";
        els.progressFill.style.width = "100%";
        els.progressBar.setAttribute("aria-valuenow", "100");
        els.progressLabel.textContent = "Finished";
        updatePlaybackStatus("ready", "Speech complete");
        updatePlayerButtons();
        saveCurrentTextToHistory(true);
      }
    };
    utterance.onerror = (event) => {
      if (sessionId !== state.session || event.error === "canceled" || event.error === "interrupted") return;
      state.utterance = null;
      state.status = "error";
      updatePlaybackStatus("error", "Speech error");
      updatePlayerButtons();
      showNotification(`Speech could not continue${event.error ? ` (${event.error})` : ""}. Try again or choose another voice.`);
    };
    return utterance;
  }

  function speakText() {
    if (!validateText()) return;
    const synth = window.speechSynthesis;
    synth.cancel(); // Clear any queued/previous utterances before a new session.
    state.session += 1;
    const sessionId = state.session;
    state.chunks = splitTextIntoChunks(els.textInput.value);
    state.chunkIndex = 0;
    state.lastSpokenText = els.textInput.value;
    state.status = "starting";
    els.progressFill.style.width = "0%";
    els.progressBar.setAttribute("aria-valuenow", "0");
    els.progressLabel.textContent = "Timing unavailable";
    updateActiveVoiceInfo();
    updatePlaybackStatus("starting", "Preparing speech…");
    updatePlayerButtons();
    saveCurrentTextToHistory(true);
    // Some browsers need a brief gap after cancel() before speaking again.
    window.setTimeout(() => {
      if (sessionId === state.session) speakNextChunk(sessionId);
    }, 30);
  }

  function speakNextChunk(sessionId) {
    if (sessionId !== state.session || state.status === "stopped") return;
    if (state.chunkIndex >= state.chunks.length) return;
    state.utterance = createUtterance(state.chunks[state.chunkIndex], sessionId);
    window.speechSynthesis.speak(state.utterance);
  }

  function pauseSpeech() {
    if (!("speechSynthesis" in window) || state.status !== "playing") return;
    window.speechSynthesis.pause();
    state.status = "paused";
    updatePlaybackStatus("paused", "Speech paused");
    updatePlayerButtons();
  }

  function resumeSpeech() {
    if (!("speechSynthesis" in window) || state.status !== "paused") return;
    window.speechSynthesis.resume();
    state.status = "playing";
    updatePlaybackStatus("playing", "Speaking");
    updatePlayerButtons();
  }

  function stopSpeech(showToast = false) {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    state.session += 1; // Ignore callbacks from the cancelled session.
    state.utterance = null;
    state.chunks = [];
    state.chunkIndex = 0;
    state.status = "stopped";
    els.progressFill.style.width = "0%";
    els.progressBar.setAttribute("aria-valuenow", "0");
    els.progressLabel.textContent = "Stopped";
    updatePlaybackStatus("stopped", "Speech stopped");
    updatePlayerButtons();
    if (showToast) showNotification("Speech stopped.");
  }

  function previewVoice() {
    if (!("speechSynthesis" in window)) {
      showNotification("Speech synthesis is not supported in this browser.");
      return;
    }
    if (els.voiceSelect.disabled || !els.voiceSelect.value) {
      showNotification("No voice is available for this language. Choose another language.");
      return;
    }
    window.speechSynthesis.cancel();
    state.session += 1;
    const sessionId = state.session;
    const sample = languageSample(els.languageSelect.value);
    state.chunks = [sample];
    state.chunkIndex = 0;
    state.status = "starting";
    updateActiveVoiceInfo();
    updatePlaybackStatus("starting", "Previewing voice…");
    updatePlayerButtons();
    window.setTimeout(() => {
      if (sessionId !== state.session) return;
      state.utterance = createUtterance(sample, sessionId);
      // Preview is a separate one-chunk session; end handler returns to ready.
      window.speechSynthesis.speak(state.utterance);
    }, 30);
  }

  function languageSample(lang) {
    const samples = {
      "en-US":"Hello! This is a preview of your selected voice.",
      "en-GB":"Hello! This is a preview of your selected voice.",
      "hi-IN":"नमस्ते! यह आपकी चुनी हुई आवाज़ का नमूना है।",
      "mr-IN":"नमस्कार! हा तुमच्या निवडलेल्या आवाजाचा नमुना आहे.",
      "es-ES":"¡Hola! Esta es una muestra de la voz seleccionada.",
      "fr-FR":"Bonjour ! Ceci est un aperçu de la voix sélectionnée.",
      "de-DE":"Hallo! Dies ist eine Vorschau der ausgewählten Stimme.",
      "ja-JP":"こんにちは。選択した音声のサンプルです。",
      "ar-SA":"مرحبًا! هذه عينة من الصوت الذي اخترته."
    };
    return samples[lang] || "Hello! This is a preview of your selected voice.";
  }

  function updatePlaybackStatus(status, message) {
    state.status = status;
    els.playbackStatus.dataset.state = status;
    els.playbackStatus.replaceChildren();
    const dot = document.createElement("span");
    dot.className = "status-dot";
    dot.setAttribute("aria-hidden", "true");
    els.playbackStatus.append(dot, document.createTextNode(message));
  }

  function updatePlayerButtons() {
    const active = ["starting","playing","paused"].includes(state.status);
    els.pauseBtn.disabled = state.status !== "playing";
    els.resumeBtn.disabled = state.status !== "paused";
    els.stopBtn.disabled = !active;
    els.playBtn.disabled = !els.textInput.value.trim() || !("speechSynthesis" in window);
  }

  function updateActiveVoiceInfo() {
    const voice = state.voices.find((v) => v.voiceURI === els.voiceSelect.value);
    els.activeVoiceName.textContent = voice ? voice.name : "Default browser voice";
    els.activeLanguage.textContent = languageNames.get(els.languageSelect.value) || els.languageSelect.value;
  }

  function updateSliderLabels() {
    els.rateValue.textContent = `${Number(els.rateSlider.value).toFixed(1)}×`;
    els.pitchValue.textContent = Number(els.pitchSlider.value).toFixed(1);
    els.volumeValue.textContent = `${Math.round(Number(els.volumeSlider.value) * 100)}%`;
  }

  function resetSettings() {
    els.languageSelect.value = "en-US";
    els.rateSlider.value = "1";
    els.pitchSlider.value = "1";
    els.volumeSlider.value = "1";
    populateVoiceOptions();
    updateSliderLabels();
    updateActiveVoiceInfo();
    showNotification("Voice settings reset.");
  }

  async function copyText() {
    const text = els.textInput.value;
    if (!text) { showNotification("There is no text to copy."); return; }
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        fallbackCopy(text);
      }
      showNotification("Text copied to clipboard.");
    } catch (error) {
      try { fallbackCopy(text); showNotification("Text copied to clipboard."); }
      catch (_) { showNotification("Clipboard access was denied. Select the text and copy it manually."); }
    }
  }

  function fallbackCopy(text) {
    const temporary = document.createElement("textarea");
    temporary.value = text;
    temporary.setAttribute("readonly", "");
    temporary.style.position = "fixed";
    temporary.style.opacity = "0";
    document.body.append(temporary);
    temporary.select();
    const ok = document.execCommand("copy");
    temporary.remove();
    if (!ok) throw new Error("Copy command failed");
  }

  async function pasteText() {
    try {
      if (!navigator.clipboard || !navigator.clipboard.readText) {
        showNotification("Clipboard paste is unavailable here. Tap the editor and paste manually.");
        els.textInput.focus();
        return;
      }
      const text = await navigator.clipboard.readText();
      if (!text) { showNotification("Your clipboard is empty."); return; }
      const combined = (els.textInput.value + text).slice(0, MAX_CHARS);
      els.textInput.value = combined;
      updateTextCounters();
      els.validationMessage.textContent = "";
      saveCurrentTextToHistory(true);
      showNotification(combined.length >= MAX_CHARS ? "Pasted text reached the character limit." : "Text pasted.");
    } catch (error) {
      showNotification("Clipboard permission was denied. Tap the editor and paste manually.");
      els.textInput.focus();
    }
  }

  function saveCurrentTextToHistory(force) {
    const text = els.textInput.value.trim();
    if (!text) return;
    if (!force && text.length < 8) return;
    state.history = state.history.filter((item) => item.text !== text);
    state.history.unshift({ id: `${Date.now()}-${Math.random().toString(36).slice(2,7)}`, text, savedAt: Date.now() });
    state.history = state.history.slice(0, 8);
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(state.history));
      renderHistory();
    } catch (_) {
      showNotification("Local storage is unavailable. Your text will not be saved after closing this page.");
    }
  }

  function loadHistory() {
    try {
      const parsed = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
      state.history = Array.isArray(parsed) ? parsed.filter((x) => x && typeof x.text === "string" && x.text.trim()).slice(0,8) : [];
    } catch (_) { state.history = []; }
    renderHistory();
    if (state.history.length) {
      els.textInput.value = state.history[0].text;
      updateTextCounters();
    }
  }

  function renderHistory() {
    const selected = els.recentSelect.value;
    els.recentSelect.replaceChildren();
    if (!state.history.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No saved text yet";
      els.recentSelect.append(option);
      els.recentSelect.disabled = true;
      els.deleteHistoryBtn.disabled = true;
      return;
    }
    state.history.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.id;
      const date = new Date(item.savedAt).toLocaleString([], { month:"short", day:"numeric", hour:"2-digit", minute:"2-digit" });
      const preview = item.text.replace(/\s+/g," ").slice(0,38);
      option.textContent = `${preview}${item.text.length > 38 ? "…" : ""} · ${date}`;
      els.recentSelect.append(option);
    });
    els.recentSelect.disabled = false;
    els.deleteHistoryBtn.disabled = false;
    if (state.history.some((item) => item.id === selected)) els.recentSelect.value = selected;
    else els.recentSelect.value = state.history[0].id;
  }

  function clearHistory() {
    state.history = [];
    try { localStorage.removeItem(HISTORY_KEY); } catch (_) {}
    renderHistory();
    showNotification("Saved text history cleared.");
  }

  function loadTheme() {
    let theme = "light";
    try { theme = localStorage.getItem(THEME_KEY) || "light"; } catch (_) {}
    document.body.classList.toggle("dark", theme === "dark");
    updateThemeButton(theme);
  }

  function toggleTheme() {
    const isDark = !document.body.classList.contains("dark");
    document.body.classList.toggle("dark", isDark);
    try { localStorage.setItem(THEME_KEY, isDark ? "dark" : "light"); } catch (_) {}
    updateThemeButton(isDark ? "dark" : "light");
  }

  function updateThemeButton(theme) {
    const dark = theme === "dark";
    els.themeToggle.innerHTML = `<span aria-hidden="true">${dark ? "☀" : "☾"}</span>`;
    els.themeToggle.setAttribute("aria-label", dark ? "Switch to light mode" : "Switch to dark mode");
  }

  function openConfirm(title, message, buttonText, action) {
    els.dialogTitle.textContent = title;
    els.dialogMessage.textContent = message;
    els.confirmActionBtn.textContent = buttonText;
    state.dialogAction = action;
    if (typeof els.confirmDialog.showModal === "function") els.confirmDialog.showModal();
    else if (window.confirm(message)) { state.dialogAction = null; action(); }
  }

  function showNotification(message) {
    els.toast.textContent = message;
    els.toast.classList.add("visible");
    if (state.toastTimer) window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => els.toast.classList.remove("visible"), 3000);
  }

  async function downloadAudio() {
    // Web Speech API exposes playback controls, not the synthesized audio bytes.
    // Keep this guarded so browser-only mode never fabricates an audio file.
    showNotification("Connect a real audio-generating TTS provider to download MP3 or WAV.");
  }

  initializeApp();
})();
